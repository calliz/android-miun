/** Automatically generated file. DO NOT MODIFY */
package com.example.robberlanguage;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}